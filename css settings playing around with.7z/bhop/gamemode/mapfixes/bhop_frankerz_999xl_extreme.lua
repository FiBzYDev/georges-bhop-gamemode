HOOKS["InitPostEntity"] = function()
	RunConsoleCommand("sv_maxvelocity","9999999")
end